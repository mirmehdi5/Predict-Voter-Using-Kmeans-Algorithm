package com.ec.lab;


import java.util.*;
import java.io.*;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.mapred.Reducer;

 @SuppressWarnings("deprecation")
 public class KmeansMR {
     public static String OUT = "outfile";
     public static String IN = "inputlarger";
     public static String CENTROID_FILE_NAME = "/centroidrun1.txt";
     public static String OUTPUT_FILE_NAME = "/part-00000";
     public static String DATA_FILE_NAME = "/voterun1.txt";
     public static String JOB_NAME = "KMeans";
     public static String SPLITTER = "\t| ";
     

     public static class Map extends MapReduceBase implements
             Mapper<Object, Text, IntWritable, Text> {
    	 public static List<String[]> mCenters;
    	 
         @Override
         public void configure(JobConf job) {
             try {
                 // Fetch the file from Distributed Cache Read it and store the
                 // centroid in the ArrayList
                 Path[] cacheFiles = DistributedCache.getLocalCacheFiles(job);
                 if (cacheFiles != null && cacheFiles.length > 0) {
                	 
                	 mCenters = readCentroids(cacheFiles[0].toString());
                 }
             } catch (IOException e) {
                 System.err.println("Exception reading DistribtuedCache: " + e);
             }
         }

         @Override
         public void map(Object key, Text value,
                 OutputCollector<IntWritable, Text> output,
                 Reporter reporter) throws IOException {
        	 
        	 
        	 String[] xy = value.toString().split(",");
             double a = Double.parseDouble(xy[0]);
             double b = Double.parseDouble(xy[1]);
             double c = Double.parseDouble(xy[2]);
             double d = Double.parseDouble(xy[3]);
             
             double e = Double.parseDouble(xy[4]);
             double f = Double.parseDouble(xy[5]);
             double g = Double.parseDouble(xy[6]);
             double h = Double.parseDouble(xy[7]);
             
             double i = Double.parseDouble(xy[8]);
             double j = Double.parseDouble(xy[9]);
             double k = Double.parseDouble(xy[10]);
             double l = Double.parseDouble(xy[11]);
             
             double m = Double.parseDouble(xy[12]);
             double n = Double.parseDouble(xy[13]);
             double o = Double.parseDouble(xy[14]);
             double p = Double.parseDouble(xy[15]);
             String party = xy[16];
             
             int index = 0;
             if(party.equals("democrat")){
            	 double minDistance = Double.MAX_VALUE;
                 for (int ind = 0; ind < mCenters.size(); ind++) {
                    // double distance = Utils.euclideanDistance(mCenters.get(j)[0], mCenters.get(j)[1], x, y);
                     double distance = calculateDistance(Double.parseDouble(mCenters.get(ind)[0]), Double.parseDouble(mCenters.get(ind)[1]), Double.parseDouble(mCenters.get(ind)[2]), Double.parseDouble(mCenters.get(ind)[3]), Double.parseDouble(mCenters.get(ind)[4]), Double.parseDouble(mCenters.get(ind)[5]), Double.parseDouble(mCenters.get(ind)[6]), Double.parseDouble(mCenters.get(ind)[7]), Double.parseDouble(mCenters.get(ind)[8]), Double.parseDouble(mCenters.get(ind)[9]), Double.parseDouble(mCenters.get(ind)[10]), Double.parseDouble(mCenters.get(ind)[11]), Double.parseDouble(mCenters.get(ind)[12]), Double.parseDouble(mCenters.get(ind)[13]), Double.parseDouble(mCenters.get(ind)[14]), Double.parseDouble(mCenters.get(ind)[15]), a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p);
                     if (distance < minDistance) {
                         index = ind;
                         minDistance = distance;
                     }
                 }
             }else{
            	 double minDistance = Double.MAX_VALUE;
                 for (int ind = 0; ind < mCenters.size(); ind++) {
                    // double distance = Utils.euclideanDistance(mCenters.get(j)[0], mCenters.get(j)[1], x, y);
                     double distance = calculateDistance(Double.parseDouble(mCenters.get(ind)[0]), Double.parseDouble(mCenters.get(ind)[1]), Double.parseDouble(mCenters.get(ind)[2]), Double.parseDouble(mCenters.get(ind)[3]), Double.parseDouble(mCenters.get(ind)[4]), Double.parseDouble(mCenters.get(ind)[5]), Double.parseDouble(mCenters.get(ind)[6]), Double.parseDouble(mCenters.get(ind)[7]), Double.parseDouble(mCenters.get(ind)[8]), Double.parseDouble(mCenters.get(ind)[9]), Double.parseDouble(mCenters.get(ind)[10]), Double.parseDouble(mCenters.get(ind)[11]), Double.parseDouble(mCenters.get(ind)[12]), Double.parseDouble(mCenters.get(ind)[13]), Double.parseDouble(mCenters.get(ind)[14]), Double.parseDouble(mCenters.get(ind)[15]), a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p);
                     if (distance < minDistance) {
                         index = ind;
                         minDistance = distance;
                     }
                 }
             }
             
             
             // Emit the nearest center and the point
             output.collect(new IntWritable(index), value);
         }
         
         public static List<String[]> readCentroids(String filename) throws IOException {
             FileInputStream fileInputStream = new FileInputStream(filename);
             BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));
             return  readData(reader);
         }
         
         private static List<String[]> readData(BufferedReader reader) throws IOException {
             List<String[]> centroids = new ArrayList<>();
             String line;
             try {
                 while ((line = reader.readLine()) != null) {
                     String[] values = line.split("\t");
                     String[] temp = values[0].split(",");
                     String[] centroid = new String[17];
                     centroid[0] = temp[0];
                     centroid[1] = temp[1];
                     centroid[2] = temp[2];
                     centroid[3] = temp[3];
                     centroid[4] = temp[4];
                     centroid[5] = temp[5];
                     centroid[6] = temp[6];
                     centroid[7] = temp[7];
                     centroid[8] = temp[8];
                     centroid[9] = temp[9];
                     centroid[10] = temp[10];
                     centroid[11] = temp[11];
                     centroid[12] = temp[12];
                     centroid[13] = temp[13];
                     centroid[14] = temp[14];
                     centroid[15] = temp[15];
                     centroid[16] = temp[16];
                     
                     centroids.add(centroid);
                 }
             }
             finally {
                 reader.close();
             }
             return centroids;
         }
         
         public static double calculateDistance(double a1, double b1, double c1, double d1, double e1, double f1, double g1, double h1, double i1, double j1, double k1, double l1, double m1, double n1, double o1, double p1, double a2, double b2, double c2, double d2, double e2, double f2, double g2, double h2, double i2, double j2, double k2, double l2, double m2, double n2, double o2, double p2) {
             return Math.sqrt(Math.pow(a1 - a2, 2) + Math.pow(b1 - b2, 2) + Math.pow(c1 - c2, 2) + Math.pow(d1 - d2, 2) + Math.pow(e1 - e2, 2) + Math.pow(f1 - f2, 2) + Math.pow(g1 - g2, 2) + Math.pow(h1 - h2, 2) + Math.pow(i1 - i2, 2) + Math.pow(j1 - j2, 2) + Math.pow(k1 - k2, 2) + Math.pow(l1 - l2, 2) + Math.pow(m1 - m2, 2) + Math.pow(n1 - n2, 2) + Math.pow(o1 - o2, 2) + Math.pow(p1 - p2, 2) );
         }
     }

     public static class Reduce extends MapReduceBase implements
             Reducer<IntWritable, Text, Text, IntWritable> {

         @Override
         public void reduce(IntWritable key, Iterator<Text> values,
                 OutputCollector<Text, IntWritable> output, Reporter reporter)
                 throws IOException {
             
             Double democrat_a = 0d;
             Double democrat_b = 0d;
             Double democrat_c = 0d;
             Double democrat_d = 0d;
             
             Double democrat_e = 0d;
             Double democrat_f = 0d;
             Double democrat_g = 0d;
             Double democrat_h = 0d;
             
             Double democrat_i = 0d;
             Double democrat_j = 0d;
             Double democrat_k = 0d;
             Double democrat_l = 0d;
             
             Double democrat_m = 0d;
             Double democrat_n = 0d;
             Double democrat_o = 0d;
             Double democrat_p = 0d;
             int democrat_counter = 0;
             
             Double republic_a = 0d;
             Double republic_b = 0d;
             Double republic_c = 0d;
             Double republic_d = 0d;
             
             Double republic_e = 0d;
             Double republic_f = 0d;
             Double republic_g = 0d;
             Double republic_h = 0d;
             
             Double republic_i = 0d;
             Double republic_j = 0d;
             Double republic_k = 0d;
             Double republic_l = 0d;
             
             Double republic_m = 0d;
             Double republic_n = 0d;
             Double republic_o = 0d;
             Double republic_p = 0d;
             int republic_counter = 0;
             
             String party ="";
        	 
             while (values.hasNext()) {
            	 
            	 String[] temp = values.next().toString().split(",");
            	 
            	 party = temp[16];
            	 if(temp[16].equals("democrat")){
                	 democrat_a += Double.parseDouble(temp[0]);
                	 democrat_b += Double.parseDouble(temp[1]);
                	 democrat_c += Double.parseDouble(temp[2]);
                	 democrat_d += Double.parseDouble(temp[3]);
                     
                	 democrat_e += Double.parseDouble(temp[4]);
                	 democrat_f += Double.parseDouble(temp[5]);
                	 democrat_g += Double.parseDouble(temp[6]);
                	 democrat_h += Double.parseDouble(temp[7]);
                     
                	 democrat_i += Double.parseDouble(temp[8]);
                	 democrat_j += Double.parseDouble(temp[9]);
                	 democrat_k += Double.parseDouble(temp[10]);
                	 democrat_l += Double.parseDouble(temp[11]);
                     
                	 democrat_m += Double.parseDouble(temp[12]);
                	 democrat_n += Double.parseDouble(temp[13]);
                	 democrat_o += Double.parseDouble(temp[14]);
                	 democrat_p += Double.parseDouble(temp[15]);
                	 democrat_counter ++;
            	 }else{
            		 republic_a += Double.parseDouble(temp[0]);
                	 republic_b += Double.parseDouble(temp[1]);
                	 republic_c += Double.parseDouble(temp[2]);
                	 republic_d += Double.parseDouble(temp[3]);
                     
                	 republic_e += Double.parseDouble(temp[4]);
                	 republic_f += Double.parseDouble(temp[5]);
                	 republic_g += Double.parseDouble(temp[6]);
                	 republic_h += Double.parseDouble(temp[7]);
                     
                	 republic_i += Double.parseDouble(temp[8]);
                	 republic_j += Double.parseDouble(temp[9]);
                	 republic_k += Double.parseDouble(temp[10]);
                	 republic_l += Double.parseDouble(temp[11]);
                     
                	 republic_m += Double.parseDouble(temp[12]);
                	 republic_n += Double.parseDouble(temp[13]);
                	 republic_o += Double.parseDouble(temp[14]);
                	 republic_p += Double.parseDouble(temp[15]);
                	 republic_counter++;
            	 }
             }
        	 
             String centroid = "";
             // We have new center now
             if(party.equals("democrat")){
            	 democrat_a = democrat_a / democrat_counter;
                 democrat_b = democrat_b / democrat_counter;
                 democrat_c = democrat_c / democrat_counter;
                 democrat_d = democrat_d / democrat_counter;
                 
                 democrat_e = democrat_e / democrat_counter;
                 democrat_f = democrat_f / democrat_counter;
                 democrat_g = democrat_g / democrat_counter;
                 democrat_h = democrat_h / democrat_counter;
                 
                 democrat_i = democrat_i / democrat_counter;
                 democrat_j = democrat_j / democrat_counter;
                 democrat_k = democrat_k / democrat_counter;
                 democrat_l = democrat_l / democrat_counter;
                 
                 democrat_m = democrat_m / democrat_counter;
                 democrat_n = democrat_n / democrat_counter;
                 democrat_o = democrat_o / democrat_counter;
                 democrat_p = democrat_p / democrat_counter;
                 centroid = democrat_a + "," + democrat_b + "," + democrat_c + "," + democrat_d + "," + democrat_e + "," + democrat_f + "," + democrat_g + "," + democrat_h + "," + democrat_i + "," + democrat_j + "," + democrat_j + "," + democrat_l + "," + democrat_m + "," + democrat_n + "," + democrat_o + "," + democrat_p + "," + party  ;
             }else{
            	 republic_a = republic_a / republic_counter;
                 republic_b = republic_b / republic_counter;
                 republic_c = republic_c / republic_counter;
                 republic_d = republic_d / republic_counter;
                 
                 republic_e = republic_e / republic_counter;
                 republic_f = republic_f / republic_counter;
                 republic_g = republic_g / republic_counter;
                 republic_h = republic_h / republic_counter;
                 
                 republic_i = republic_i / republic_counter;
                 republic_j = republic_j / republic_counter;
                 republic_k = republic_k / republic_counter;
                 republic_l = republic_l / republic_counter;
                 
                 republic_m = republic_m / republic_counter;
                 republic_n = republic_n / republic_counter;
                 republic_o = republic_o / republic_counter;
                 republic_p = republic_p / republic_counter;
                 centroid = republic_a + "," + republic_b + "," + republic_c + "," + republic_d + "," + republic_e + "," + republic_f + "," + republic_g + "," + republic_h + "," + republic_i + "," + republic_j + "," + republic_j + "," + republic_l + "," + republic_m + "," + republic_n + "," + republic_o + "," + republic_p + "," + party;
             }
             
             
             
             // Emit new center and point
             output.collect(new Text(centroid), key);
         }
     }

     public static void main(String[] args) throws Exception {
         run(args);
     }

     public static void run(String[] args) throws Exception {
         IN = args[0];
         OUT = args[1];
         String input = IN;
         String output = OUT + System.nanoTime();
         //String output = OUT;
         String again_input = output;

         // Reiterating till the convergence
         int iteration = 0;
         boolean hasConverged = false;
         
         
         while (hasConverged == false) {
             JobConf conf = new JobConf(KmeansMR.class);
             if (iteration == 0) {
                 Path hdfsPath = new Path(input + CENTROID_FILE_NAME);
                 // upload the file to hdfs. Overwrite any existing copy.
                 DistributedCache.addCacheFile(hdfsPath.toUri(), conf);
             } else {
                 Path hdfsPath = new Path(again_input + OUTPUT_FILE_NAME);
                 // upload the file to hdfs. Overwrite any existing copy.
                 DistributedCache.addCacheFile(hdfsPath.toUri(), conf);
             }

             conf.setJobName(JOB_NAME);
             conf.setMapOutputKeyClass(IntWritable.class);
             conf.setMapOutputValueClass(Text.class);
             conf.setOutputKeyClass(Text.class);
             conf.setOutputValueClass(IntWritable.class);
             conf.setMapperClass(Map.class);
             conf.setReducerClass(Reduce.class);
             conf.setInputFormat(TextInputFormat.class);
             conf.setOutputFormat(TextOutputFormat.class);

             FileInputFormat.setInputPaths(conf,
                     new Path(input + DATA_FILE_NAME));
             FileOutputFormat.setOutputPath(conf, new Path(output));

             JobClient.runJob(conf);

             Path ofile = new Path(output + OUTPUT_FILE_NAME);
             FileSystem fs = FileSystem.get(new Configuration());
             BufferedReader br = new BufferedReader(new InputStreamReader(
                     fs.open(ofile)));
             
             
             StringBuilder content = new StringBuilder();
            // List<Double> centers_next = new ArrayList<Double>();
             String line = br.readLine();
             while (line != null) {
            	 content.append(line).append("\n");
                 line = br.readLine();
             }
             br.close();
             
             String newCentroids = content.toString();
             
             String prev;
             if (iteration == 0) {
                 prev = input + CENTROID_FILE_NAME;
             } else {
                 prev = again_input + OUTPUT_FILE_NAME;
             }
             Path prevfile = new Path(prev);
             FileSystem fs1 = FileSystem.get(new Configuration());
             BufferedReader br1 = new BufferedReader(new InputStreamReader(
                     fs1.open(prevfile)));
             StringBuilder content1 = new StringBuilder();
             String l = br1.readLine();
             while (l != null) {
            	 content1.append(l).append("\n");
                 l = br1.readLine();
             }
             br1.close();
             
             String prevCentroids = content1.toString();
             
             if (prevCentroids.equals(newCentroids)) {

                 // it means that the iteration is finished
                 hasConverged = true;
             }

            // prevCentroids = newCentroids;
             ++iteration;
             again_input = output;
             output = OUT + System.nanoTime();
             //output = OUT;
         }
     }
 }